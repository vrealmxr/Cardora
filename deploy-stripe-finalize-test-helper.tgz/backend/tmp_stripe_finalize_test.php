<?php

declare(strict_types=1);

use App\Models\Order;
use App\Services\StripeMarketplaceService;
use Illuminate\Contracts\Console\Kernel;

require __DIR__.'/vendor/autoload.php';

$app = require __DIR__.'/bootstrap/app.php';
$app->make(Kernel::class)->bootstrap();

$order = Order::query()->findOrFail(26);

$service = app(StripeMarketplaceService::class);
$service->confirmSuccessfulPayment($order, [
    'stripe_payment_intent_id' => 'pi_3Tow5VE2tqs7eIUL0z8rjvmO',
    'stripe_charge_id' => 'ch_3Tow5VE2tqs7eIUL0ppwZw0m',
    'payment_status' => 'succeeded',
]);

$fresh = Order::query()->findOrFail(26);

echo json_encode([
    'id' => $fresh->id,
    'order_number' => $fresh->order_number,
    'status' => $fresh->status,
    'escrow_status' => $fresh->escrow_status,
    'shipment_status' => $fresh->shipment_status,
    'subtotal' => (float) $fresh->subtotal,
    'shipping_total' => (float) $fresh->shipping_total,
    'commission_amount' => (float) $fresh->commission_amount,
    'seller_amount' => (float) $fresh->seller_amount,
    'total_amount' => (float) $fresh->total_amount,
    'stripe_payment_intent_id' => $fresh->stripe_payment_intent_id,
    'stripe_charge_id' => $fresh->stripe_charge_id,
    'stripe_transfer_id' => $fresh->stripe_transfer_id,
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES).PHP_EOL;
