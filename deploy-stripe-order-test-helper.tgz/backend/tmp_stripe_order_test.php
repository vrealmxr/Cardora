<?php

declare(strict_types=1);

use App\Models\User;
use App\Services\OrderCheckoutService;
use App\Services\StripeMarketplaceService;
use Illuminate\Contracts\Console\Kernel;

require __DIR__.'/vendor/autoload.php';

$app = require __DIR__.'/bootstrap/app.php';
$app->make(Kernel::class)->bootstrap();

$buyer = User::query()->findOrFail(9);

$payload = [
    'items' => [
        [
            'listing_id' => 174,
            'quantity' => 1,
        ],
    ],
    'shipping_address' => [
        'full_name' => 'Konstantinos Loizos',
        'address_line_1' => 'Kallirrois 198',
        'city' => 'Athens',
        'postal_code' => '11852',
        'country' => 'Greece',
        'country_code' => 'GR',
        'phone' => '6972995921',
        'carrier' => 'dhl_express',
        'delivery_type' => 'service_point',
        'service_point' => [
            'id' => 'ATHD7D',
            'name' => 'Skroutz Point Locker 24/7 Pan-Door (Athens)',
            'address' => 'Kallirrois 198',
            'carrier' => 'dhl_express',
        ],
    ],
    'currency' => 'EUR',
];

$order = app(OrderCheckoutService::class)->createPendingOrder($buyer, $payload);
$intent = app(StripeMarketplaceService::class)->createPaymentIntentForOrder($order);

echo json_encode([
    'order_id' => $order->id,
    'order_number' => $order->order_number,
    'subtotal' => (float) $order->subtotal,
    'shipping_total' => (float) $order->shipping_total,
    'commission_amount' => (float) $order->commission_amount,
    'seller_amount' => (float) $order->seller_amount,
    'total_amount' => (float) $order->total_amount,
    'payment_intent_id' => $intent->id,
    'client_secret' => $intent->client_secret,
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES).PHP_EOL;
